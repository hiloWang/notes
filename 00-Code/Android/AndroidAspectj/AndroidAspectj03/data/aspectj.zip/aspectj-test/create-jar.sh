#!/bin/sh
ajc -sourceroots test -1.7 
jar -cvfm test.jar test/manifest.mf test
